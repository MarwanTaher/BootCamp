/*
 * Scheduler.h
 *
 * Created: 2/23/2019 2:39:21 PM
 *  Author: AVE-LAP-071
 */ 

#include "../Includes/Types.h"
#include "../Includes/Timer.h"
#include "Tasks.h"


#ifndef SCHEDULER_H_
#define SCHEDULER_H_


#define COMPARETIME 250

#define ONESECOND 1000	
#define TWOSECONDS	2000
#define THREESECONDS  3000
#define FOURSECONDS	4000	
#define FIVESECONDS 5000
#define ACTIVE 1
#define NOTACTIVE 0

typedef void (*Task_Type) (void);


/************************************************************************/
/* Flag_Check */
/* Parameters : Null */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* Check on the ISR flag */
/************************************************************************/


void Flag_Check(void);


/************************************************************************/
/* Dispatcher */
/* Parameters : arr[],Number_of_Arrays */
/* I/p : (void) (*arr[])(void), uint8 Number_of_Arrays */
/* O/p : void */
/* Return : void */
/* Dispatch the tasks one by one */
/************************************************************************/

	
void Dispatcher(void);	



/************************************************************************/
/* SchedulerStart */
/* Parameters : void */
/* I/p : void  */
/* O/p : void */
/* Return : void */
/* Scheduler initialization and starting the program */
/************************************************************************/

void SchedulerStart(void);


/************************************************************************/
/* OS_Timer_init */
/* Parameters : Null */
/* I/p : uint8 Compare_Time */
/* O/p : void */
/* Return : void */
/* Initialize Timer Zero with CTC mode */
/************************************************************************/
extern void OS_Timer_init(uint8 Compare_Time);

/************************************************************************/
/* SchedulerInit */
/* Parameters : void */
/* I/p : void  */
/* O/p : void */
/* Return : void */
/* Scheduler initialization  */
/************************************************************************/

void SchedulerInit(void);

/************************************************************************/
/* SortTasks */
/* Parameters : void */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* sort the tasks by priority */
/************************************************************************/

void SortTasks(void);

/************************************************************************/
/* Scheduler_Add_Task */
/* Parameters : NEWTASK,PERIOD,STATE */
/* I/p : (void) (*arr[])(void), uint32 Period,uint8 state */
/* O/p : void */
/* Return : void */
/* Adds new tasks to the queue  */
/************************************************************************/
void Scheduler_Add_Task (Task_Type NewTask, uint32 period,uint8 Priority,uint8 state);

/************************************************************************/
/* scheduler_Remove_Task */
/* Parameters : void (*arr[]) (void) */
/* I/p : (void) (*arr[])(void) */
/* O/p : void */
/* Return : void */
/* Dispatch the tasks one by one */
/************************************************************************/
void scheduler_Remove_Task(Task_Type NewTask);

#endif /* SCHEDULER_H_ */