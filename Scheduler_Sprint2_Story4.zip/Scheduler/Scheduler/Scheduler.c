/*
 * Scheduler.c
 *
 * Created: 2/23/2019 2:38:58 PM
 *  Author: AVE-LAP-071
 */ 
#include "Scheduler.h"


callback_Type callback_ptr_Main=Flag_Check;
volatile uint8 Flag=0;
volatile uint32 Task=0;
volatile uint32 Task_Queue=0;
volatile uint8 Success=0;




/************************************************************************/
/* SchedulerInit */
/* Parameters : void */
/* I/p : void  */
/* O/p : void */
/* Return : void */
/* Scheduler initialization  */
/************************************************************************/
void SchedulerInit(void)
{
		Scheduler_Add_Task(Task_5,FIVESECONDS,ZERO,ACTIVE);
		Scheduler_Add_Task(Task_4,TWOSECONDS,THREE,ACTIVE);
		Scheduler_Add_Task(Task_2,ONESECOND,FOUR,ACTIVE);
		Scheduler_Add_Task(Task_3,THREESECONDS,TWO,ACTIVE);
		Scheduler_Add_Task(Task_1,FOURSECONDS,ONE,ACTIVE);
		
		SortTasks();  /*TASKS SORTING*/
		OS_Timer_init(COMPARETIME);      /*TIMER_INITIALIZING*/
}







/************************************************************************/
/* SchedulerStart */
/* Parameters : void */
/* I/p : void  */
/* O/p : void */
/* Return : void */
/* Scheduler initialization and starting the program */
/************************************************************************/


void SchedulerStart(void)
{

	SetCallBack(callback_ptr_Main);  /*SETTING CALL BACK*/

	
while(1)
{
	if (Flag==TRUE)  /*FLAG TO CHECK FOR NEW TICK*/
	{
 			if(DIO_ReadPin(BUTTON1)==PRESSED)
			 {
 				scheduler_Remove_Task(Task_5);
			 }
		Flag=FALSE;
		Dispatcher(); /*CALL DISPATCHER*/
	}
}
if (Success==FALSE)

{
	/*Return False*/
}
}





/************************************************************************/
/* Flag_Check */
/* Parameters : Null */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* Check on the ISR flag */
/************************************************************************/

void Flag_Check(void)
{
	
	Flag=ONE;


}




/************************************************************************/
/* Dispatcher */
/* Parameters :void */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* Dispatch the tasks one by one */
/************************************************************************/

void Dispatcher(void)
{

	{

		for (Task=0;Task<Task_Queue;Task++)
		{
			Task_array[Task].RemforTask--;
			if (Task_array[Task].RemforTask == ZERO && Task_array[Task].State == ACTIVE) /*CHECK IF THE Task PERIODICITY IS EQUAL ZERO*/
			{
			Task_array[Task].RemforTask=Task_array[Task].Periodicity;
			(Task_array[Task].PointerToFunc());

		
			}
		}
	}	
}





/************************************************************************/
/* Scheduler_Add_Task */
/* Parameters : NEWTASK,PERIOD,STATE */
/* I/p : (void) (*arr[])(void), uint32 Period,uint8 state */
/* O/p : void */
/* Return : void */
/* Adds new tasks to the queue  */
/************************************************************************/

void Scheduler_Add_Task (Task_Type NewTask,uint32 Period,uint8 Priority,uint8 State)
{
	uint8 ArrayIndex;
	
	for(ArrayIndex=0;ArrayIndex<Task_Queue;ArrayIndex++)  /*Replacing Not Active Tasks with new tasks*/
	{
		if(Task_array[ArrayIndex].State==NOTACTIVE)
		{
			Task_array[ArrayIndex].PointerToFunc = NewTask;
			Task_array[ArrayIndex].Periodicity=Period;
			Task_array[ArrayIndex].RemforTask=Period;
			Task_array[ArrayIndex].Priority=Priority;
			Task_array[ArrayIndex].State=State;
		}
		else{}
			
	}
			
			if (Task_Queue<MaxSize)  /*ADDING NEW TASKS*/
			{
				
				Task_array[Task_Queue].PointerToFunc = NewTask;
				Task_array[Task_Queue].Periodicity=Period;
				Task_array[Task_Queue].RemforTask=Period;
				Task_array[Task_Queue].Priority=Priority;
				Task_array[Task_Queue].State=State;
				Task_Queue++;
				Success = TRUE;

			}
			
			else
			{
				
				Success=FALSE;
			}
			
		}

	

/************************************************************************/
/* SortTasks */
/* Parameters : void */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* sort the tasks by priority */
/************************************************************************/

void SortTasks(void) 
{
	
			for (uint8 i=0;i<Task_Queue;i++)
			{
				for (uint8 j=i+1;j<Task_Queue;j++)
				{
					if(Task_array[j].Priority>Task_array[i].Priority)   /*Sorting*/
					{
						Temp=Task_array[i];
						Task_array[i]=Task_array[j];
						Task_array[j]=Temp;
					}
				}
			}
}

/************************************************************************/
/* scheduler_Remove_Task */
/* Parameters : void (*arr[]) (void) */
/* I/p : (void) (*arr[])(void) */
/* O/p : void */
/* Return : void */
/* Dispatch the tasks one by one */
/************************************************************************/
 void scheduler_Remove_Task(Task_Type NewTask)
{
	uint8 ArrayIndex;
	
	for(ArrayIndex = ZERO ; ArrayIndex < Task_Queue; ArrayIndex++)
	{
		if ( Task_array[ArrayIndex].PointerToFunc == NewTask)  
		{
			Task_array[ArrayIndex].State = NOTACTIVE;   /*Remove tasks*/
		}
	}
	
}