/*
 * Tasks.h
 *
 * Created: 2/23/2019 3:01:13 PM
 *  Author: AVE-LAP-071
 */ 

#include "../Includes/Dio.h"
#include "../Includes/Timer.h"
#include "../LED/LED.h"


#ifndef TASKS_H_
#define TASKS_H_
#define Number_of_Tasks 0
#define MaxSize 10
typedef void (*Task_Type) (void);
Task_Type Taskarr[MaxSize];

struct Tasks
{
Task_Type PointerToFunc;
uint32 Periodicity;
uint32 RemforTask;
uint8 Priority;	
uint8 State;
}Task_array[MaxSize],Temp;

void Task_1(void);
void Task_2(void);
void Task_3(void);
void Task_4(void);
void Task_5(void);

void Task_init(void);

#endif /* TASKS_H_ */