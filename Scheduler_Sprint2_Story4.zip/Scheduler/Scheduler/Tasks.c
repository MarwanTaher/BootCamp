/*
 * Tasks.c
 *
 * Created: 2/23/2019 3:00:58 PM
 *  Author: AVE-LAP-071
 */ 
#include "Tasks.h"


uint8 TasksQueuesize=Number_of_Tasks;


void Task_init(void)
{
	DIO_SetPinDirection(PIN13,OUTPUT);
	DIO_SetPinDirection(PIN12,OUTPUT);
	DIO_SetPinDirection(PIN14,OUTPUT);
	DIO_SetPinDirection(PIN15,OUTPUT);	
	DIO_SetPinDirection(PIN10,INPUT);	
}


void Task_1(void)
{


LED_ON(LED0);
LED_OFF(LED2);
LED_OFF(LED3);
LED_OFF(LED1);


	
}

void Task_2(void)
{

	
LED_ON(LED1);
LED_OFF(LED0);
LED_OFF(LED2);
LED_OFF(LED3);

}

void Task_3(void)
{


LED_ON(LED2);
LED_OFF(LED3);
LED_OFF(LED1);
LED_OFF(LED0);

}

void Task_4(void)
{

LED_ON(LED3);
LED_OFF(LED2);
LED_OFF(LED0);
LED_OFF(LED1);


}
void Task_5(void)
{

LED_ON(LED1);
LED_ON(LED2);
LED_ON(LED3);
LED_ON(LED0);


	
}


	
