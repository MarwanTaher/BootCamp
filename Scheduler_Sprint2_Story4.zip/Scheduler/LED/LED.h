/*
 * LED.h
 *
 * Created: 2/25/2019 11:59:26 AM
 *  Author: AVE-LAP-071
 */ 

#include "../Includes/BitwiseOperation.h"
#include "../Includes/Dio.h"
#include "../Includes/MEM_MAP_REG.h"
#include "../Includes/Types.h"

#ifndef LED_H_
#define LED_H_

void LED_ON (uint8 LED_NO);
void LED_OFF (uint8 LED_NO);
void LED_TOG (uint8 LED_NO);


#define LED0 PIN12
#define LED1 PIN13
#define LED2 PIN14
#define LED3 PIN15


#endif /* LED_H_ */