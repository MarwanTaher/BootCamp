/*
 * LED.c
 *
 * Created: 2/25/2019 11:59:13 AM
 *  Author: AVE-LAP-071
 */ 

#include "LED.h"

void LED_ON (uint8 LED_NO)
{
	DIO_SetPinDirection(LED_NO,OUTPUT);
	DIO_WritePin(LED_NO,HIGH);
}


void LED_OFF (uint8 LED_NO)
{
	DIO_SetPinDirection(LED_NO,OUTPUT);
	DIO_WritePin(LED_NO,LOW);		
}

void LED_TOG (uint8 LED_NO)
{
	LED_ON(LED_NO);
	
	LED_OFF(LED_NO);
		
}

