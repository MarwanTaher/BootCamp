/*
 * Scheduler.h
 *
 * Created: 2/23/2019 2:39:21 PM
 *  Author: AVE-LAP-071
 */ 

#include "../Includes/Types.h"
#include "../Includes/Timer.h"
#include "Tasks.h"


#ifndef SCHEDULER_H_
#define SCHEDULER_H_


#define COMPARETIME 250



typedef void (*Task_Type) (void);


/************************************************************************/
/* Flag_Check */
/* Parameters : Null */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* Check on the ISR flag */
/************************************************************************/


void Flag_Check(void);


/************************************************************************/
/* Dispatcher */
/* Parameters : arr[],Number_of_Arrays */
/* I/p : (void) (*arr[])(void), uint8 Number_of_Arrays */
/* O/p : void */
/* Return : void */
/* Dispatch the tasks one by one */
/************************************************************************/

	
void Dispatcher(void);	



/************************************************************************/
/* SchedulerInit_AndStart */
/* Parameters : Null */
/* I/p : void  */
/* O/p : void */
/* Return : void */
/* Scheduler initialization and starting the program */
/************************************************************************/

void SchedulerStart(void);


/************************************************************************/
/* OS_Timer_init */
/* Parameters : Null */
/* I/p : uint8 Compare_Time */
/* O/p : void */
/* Return : void */
/* Initialize Timer Zero with CTC mode */
/************************************************************************/
extern void OS_Timer_init(uint8 Compare_Time);

void SchedulerInit(void);
void Scheduler_Add_Task (Task_Type NewTask, uint32 period);

#endif /* SCHEDULER_H_ */