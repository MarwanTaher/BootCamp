/*
 * Scheduler.c
 *
 * Created: 2/23/2019 2:38:58 PM
 *  Author: AVE-LAP-071
 */ 
#include "Scheduler.h"


callback_Type callback_ptr_Main=Flag_Check;
volatile uint8 Flag=0;
volatile uint32 Counter=0;
volatile uint32 Task=0;
volatile uint32 Task_Queue=0;
volatile uint32 TasksQueueSize=MaxSize-1;



void SchedulerInit(void)
{
		Scheduler_Add_Task(Task_1,1000);
		Scheduler_Add_Task(Task_2,2000);
		Scheduler_Add_Task(Task_3,3000);
		Scheduler_Add_Task(Task_4,4000);
		Scheduler_Add_Task(Task_5,5000);
}


/************************************************************************/
/* SchedulerInit_AndStart */
/* Parameters :  */
/* I/p : void  */
/* O/p : void */
/* Return : void */
/* Scheduler initialization and starting the program */
/************************************************************************/


void SchedulerStart(void)
{

	OS_Timer_init(COMPARETIME);
	SetCallBack(callback_ptr_Main);

	
while(1)
{
	if (Flag==TRUE)
	{
		Flag=FALSE;
		Dispatcher();
		
	}
}

}


/************************************************************************/
/* Flag_Check */
/* Parameters : Null */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* Check on the ISR flag */
/************************************************************************/

void Flag_Check(void)
{
	
	Flag=ONE;
	Counter++;

}


/************************************************************************/
/* Dispatcher */
/* Parameters : arr[],Number_of_Arrays */
/* I/p : (void) (*arr[])(void), uint8 Number_of_Arrays */
/* O/p : void */
/* Return : void */
/* Dispatch the tasks one by one */
/************************************************************************/

void Dispatcher(void)
{
	
for (Task=0;Task<(Task_Queue);Task++)
{
	
	if (Counter % (Task_array[Task].Periodicity)==0)
	{
		
		(Task_array[Task].PointerToFunc());
		//Task_array[Task].RemforTask=Task_array[Task].Periodicity;
		
	}
	
	
}	

		
	
	
}

uint8 Success=0;


void Scheduler_Add_Task (Task_Type NewTask,uint32 Period)
{
	if (TasksQueueSize<MaxSize)
	{	
	
			Task_array[Task_Queue].PointerToFunc = NewTask;
			Task_array[Task_Queue].Periodicity=Period;
			Task_array[Task_Queue].RemforTask=Period;
			Task_Queue++;
			Success = 1;
		
	}
	
	else
	{
		Success=0;
	}
	
}