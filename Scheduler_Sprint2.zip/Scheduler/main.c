/*
 * Scheduler.c
 *
 * Created: 2/23/2019 2:38:00 PM
 * Author : AVE-LAP-071
 */ 


#include "Scheduler/Scheduler.h"

int main(void)
{


		SchedulerInit();
		SchedulerStart();

    
}

