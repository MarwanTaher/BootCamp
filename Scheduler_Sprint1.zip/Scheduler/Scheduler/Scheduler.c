/*
 * Scheduler.c
 *
 * Created: 2/23/2019 2:38:58 PM
 *  Author: AVE-LAP-071
 */ 
#include "Scheduler.h"


callback_Type callback_ptr_Main=Flag_Check;
volatile uint8 Flag=0;
volatile uint8 Task_Queue=0;


/************************************************************************/
/* SchedulerInit_AndStart */
/* Parameters :  */
/* I/p : void  */
/* O/p : void */
/* Return : void */
/* Scheduler initialization and starting the program */
/************************************************************************/


void SchedulerInit_AndStart(void)
{

	OS_Timer_init(COMPARETIME);
	SetCallBack(callback_ptr_Main);
	
while(1)
{
	if (Flag==ONE)
	{
		Flag=ZERO;
		Dispatcher(Taskarr,Number_of_Tasks);
		
	}
}

}


/************************************************************************/
/* Flag_Check */
/* Parameters : Null */
/* I/p : void */
/* O/p : void */
/* Return : void */
/* Check on the ISR flag */
/************************************************************************/

void Flag_Check(void)
{
	
	Flag=ONE;
}


/************************************************************************/
/* Dispatcher */
/* Parameters : arr[],Number_of_Arrays */
/* I/p : (void) (*arr[])(void), uint8 Number_of_Arrays */
/* O/p : void */
/* Return : void */
/* Dispatch the tasks one by one */
/************************************************************************/

void Dispatcher(Task_Type Taskarr[],uint8 Number_of_Arrays)
{

	for (Task_Queue=ZERO;Task_Queue<Number_of_Arrays;Task_Queue++)
	{
		(Taskarr[Task_Queue])();
			
	}
	


}



