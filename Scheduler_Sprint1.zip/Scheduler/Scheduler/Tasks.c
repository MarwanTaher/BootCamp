/*
 * Tasks.c
 *
 * Created: 2/23/2019 3:00:58 PM
 *  Author: AVE-LAP-071
 */ 
#include "Tasks.h"


Task_Type Taskarr[]={Task_1,Task_2,Task_3,Task_4};


void Task_1(void)
{
	static uint16 Task_Schedule=0;
	Task_Schedule++;

if(Task_Schedule==1000)
{
	DIO_SetPinDirection(PIN13,OUTPUT);
	DIO_WritePin(PIN13,HIGH);
	DIO_WritePin(PIN14,LOW);
	DIO_WritePin(PIN15,LOW);
	Task_Schedule=0;
}

	
}
void Task_2(void)
{
	static uint16 Task_Schedule=0;
	Task_Schedule++;
	
if(Task_Schedule==2000)
{
	DIO_SetPinDirection(PIN14,OUTPUT);
	DIO_WritePin(PIN14,HIGH);
	DIO_WritePin(PIN13,LOW);
	DIO_WritePin(PIN15,LOW);
	Task_Schedule=0;
}
}
void Task_3(void)
{	static uint16 Task_Schedule=0;
	Task_Schedule++;
if(Task_Schedule==3000)
{
	DIO_SetPinDirection(PIN15,OUTPUT);
	DIO_WritePin(PIN15,HIGH);
	DIO_WritePin(PIN14,LOW);
	DIO_WritePin(PIN13,LOW);
	Task_Schedule=0;
}
}
void Task_4(void)
{
		static uint16 Task_Schedule=0;
		Task_Schedule++;
if(Task_Schedule==4000)
{
DIO_SetPinDirection(PIN15,OUTPUT);
DIO_SetPinDirection(PIN13,OUTPUT);
DIO_SetPinDirection(PIN14,OUTPUT);
DIO_WritePin(PIN15,HIGH);
DIO_WritePin(PIN14,HIGH);
DIO_WritePin(PIN13,HIGH);
	Task_Schedule=0;
}	

	
}


	
